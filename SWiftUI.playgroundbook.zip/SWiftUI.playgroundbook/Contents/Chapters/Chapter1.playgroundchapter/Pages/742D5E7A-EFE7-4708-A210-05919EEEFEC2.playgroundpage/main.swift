
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    func setInPoint()
    {
        print("set point")
    }
    func setOutPoint()
    {
        print("set out point")
    }
    var body: some View {
        VStack(alignment: .leading){ 
            //Spacer()
        HStack(){    
            
        Menu("Actions") {
            Button("Duplicate", action: {})
            Button("Rename", action: {})
            Button("Delete…", action: {})
            Menu("Copy") {
                Button("Copy", action: {})
                Button("Copy Formatted", action: {})
                Button("Copy Library Path", action: {})
            }
        } 
            
            Menu("Actions2") {
                Button("Duplicate", action: {})
                Button("Rename", action: {})
                Button("Delete…", action: {})
                Menu("Copy") {
                    Button("Copy", action: {})
                    Button("Copy Formatted", action: {})
                    Button("Copy Library Path", action: {})
                
            }
        }
            Spacer()
        }
            Spacer()
            HStack(){
                Spacer()
            Text("centre    ")
                Spacer()
            }
            Spacer()
        }
    }
    
}
PlaygroundPage.current.setLiveView(MyView())
