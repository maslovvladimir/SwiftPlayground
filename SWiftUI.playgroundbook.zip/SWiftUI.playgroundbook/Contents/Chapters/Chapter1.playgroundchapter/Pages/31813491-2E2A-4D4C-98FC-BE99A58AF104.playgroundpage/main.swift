
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    @State private var showAlert = false
    let title = "title"
    var body: some View {
        Button("Hello"){
            print("press button")
            showAlert = true
        }.alert(isPresented: $showAlert) {
            Alert(title: Text("Order Complete"),
                  message: Text("Thank you for shopping with us."),
                  dismissButton: .default(Text("OK")))
        }
    }
    
}
PlaygroundPage.current.setLiveView(MyView())

