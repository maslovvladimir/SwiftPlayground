import SwiftUI
import PlaygroundSupport

struct Message: Identifiable {
    let id = UUID()
    let text: String
}

struct MyView: View {
    @State private var showActionSheet = true
    @State private var message: Message? = nil
    @State private var showAlert = false
    
    var body: some View {
        VStack(){
            Button("Show alert") {
                showAlert = true
                print("prees alert")
                self.message = Message(text: "Hi!")
                /*Alert(title: Text("Alert work!" ) , dismissButton: .cancel())*/
            }
            .alert(isPresented: $showAlert) { () -> Alert in
                print("show alert")
                
                return Alert(title: Text("title"), dismissButton: .cancel({
                    print("cancel")
                    showAlert = false
                }))
            }
            /*.alert(item: $message, content: { message in
                Alert(title: Text(message.text), dismissButton: .cancel())
            }) */
             
            
            Button(action:  { 
                self.showActionSheet = true
            },  label: {
                Text("Show action sheet")
            }).actionSheet(isPresented: $showActionSheet, content: {
                ActionSheet(title: Text("Actions"),
                            message: Text("Available actions"),
                            buttons: [
                                .cancel({print(self.showActionSheet)}),
                                .default(Text("Action")),
                                .destructive(Text("Delete"))
                            ]
                            )
            })
            
        }
    }
    
}
// let view = MyView()
PlaygroundPage.current.setLiveView(MyView())


