
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    
    var body: some View {
        VStack {
        HStack {
            Text("LeftTop")
            Spacer()
            Text("RightTop")
        } 
            Spacer()
            HStack {
                Text("Left")
                Spacer()
                Text("Center")
                Spacer()
                Text("Right")
            }
            Spacer()
            HStack {
                Text("LeftBottom") 
                Spacer()
                Text("RightBottom")
            }
        }
    }
    
}
PlaygroundPage.current.setLiveView(MyView())
