import SwiftUI
//import Combine
import Foundation 
import PlaygroundSupport

class Data2: ObservableObject {
    //var didChange = PassthroughSubject<Void, Never>()
    @Published var txt = "txt"
    @Published var txt1 = "Hello"
}

struct MyView: View {
    @State private var txt1 = "hello"
    var body: some View {
        VStack {
            TextField("enter text here", text: $txt1  )
                .textFieldStyle(RoundedBorderTextFieldStyle())
            Text(txt1)
            Button("Button2") {
                //txt = "Press"
                txt1 = "button pressed"
                print("button2 pressed...")
            }
        }//.background(Color.yellow)
    }
    
}
let view = MyView()
PlaygroundPage.current.setLiveView(view)

