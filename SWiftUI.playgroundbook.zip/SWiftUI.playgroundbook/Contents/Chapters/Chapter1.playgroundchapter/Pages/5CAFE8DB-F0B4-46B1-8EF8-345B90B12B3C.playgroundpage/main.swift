import Foundation

let utilityQueue = DispatchQueue.global(qos: .utility)

// самый низкий приоритет
let backgroundQueue = DispatchQueue.global(priority: .background) 

// по умолчанию 
let defaultQueue = DispatchQueue.global()

func f1 ()
{
print(1)
sleep(3)
print(2)
}
utilityQueue.sync {
    f1()
}

