
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    var colors: [Color] = [.black, .red, .green, .blue]
    
    var colornames = ["Black", "Red", "Green", "Blue"]
    
    
    @State private var colorIndex = 0  
    var body: some View {
        VStack {
            Text("Hello all")
                .foregroundColor(colors[colorIndex])
        Picker(selection: $colorIndex, label: Text("Color")) {
            
            ForEach (0 ..< colornames.count) {
                
                Text(colornames[$0])
                    
                    .foregroundColor(colors[$0])
                
            }
            
        }
        }
    }
}
PlaygroundPage.current.setLiveView(MyView())
