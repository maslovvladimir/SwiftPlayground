import SwiftUI
import PlaygroundSupport

struct MyView: View {
    
    var body: some View {
        Button("Hello"){
            print("press button")
        }
    }
    
}
PlaygroundPage.current.setLiveView(MyView())

