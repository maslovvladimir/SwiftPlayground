import SwiftUI

struct MyView: View { 
    var body: some View {
    Text("3333")
} 
}
print(4444)
