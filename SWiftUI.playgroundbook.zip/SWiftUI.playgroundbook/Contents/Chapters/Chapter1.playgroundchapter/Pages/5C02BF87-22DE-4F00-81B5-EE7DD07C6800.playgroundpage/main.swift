
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    
    var body: some View {
        HStack {
            //Rectangle().fill(Color.red)
            Text("Hello").foregroundColor(.blue)  
        }.background(Color.green)
    }
    
}
let view = MyView()
PlaygroundPage.current.setLiveView(view)

    /// привет народ

