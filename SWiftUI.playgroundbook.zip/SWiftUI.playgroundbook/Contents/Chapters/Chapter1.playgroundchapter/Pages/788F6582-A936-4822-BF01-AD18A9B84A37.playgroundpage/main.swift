
func F1 () async  -> Int {  
    for i in 0...4 {
        print("F1")
    }
    return 0
}
func F2 () async   -> Int{
    for i in 0...4 {
        print("F2")
    }
    return 0
}
#if swift(== 5.5)
print("ok")
#endif
async let a = F1()
print(await a)

    
    await F2()



