
import SwiftUI
import PlaygroundSupport

struct MyView: View
{
    @State private var rotation: Double = 0
    @State private var scale: CGFloat = 1
    @State private var isStoped = false
    
    let dq = DispatchQueue.global(qos: .utility)
    
    var body: some View {
        VStack()
        {
            Spacer()
            Rectangle()
                .fill(.red)
                .frame(width: 100, height: 100) 
                .scaleEffect(scale)
                .rotationEffect(.degrees(rotation))
                .animation(.linear(duration: 2))
                .onAppear(perform: {
                    
                    print("onAppear triggered")
                    dq.async {
                        print("start async")
                        while true
                        {
                            if !isStoped
                            {
                            //print(1)
                            self.rotation = 180 
                            self.scale = 2
                        sleep(3)
                            //print(2)  
                        self.rotation = 0
                            self.scale = 1
                            sleep(3)
                            }
                        }
                    }
                    print("end async")
                })
                .onDisappear(perform: {
                    print("onDisappeared triggered")
                })
            Spacer()
            HStack {
        Button("Rotate square"){
            print("press button")
            self.rotation =
                (self.rotation < 360 ? self.rotation + 60 : 0)
            self.scale = (self.scale < 2.8 ? self.scale + 0.3 : 1)
        }
                Button("Start/Stop")
                    {
                    print("stop")
                    isStoped = !isStoped  
                    //isStoped = true
                }
            }.padding()
        }
    }

    
}

PlaygroundPage.current.setLiveView(MyView())

