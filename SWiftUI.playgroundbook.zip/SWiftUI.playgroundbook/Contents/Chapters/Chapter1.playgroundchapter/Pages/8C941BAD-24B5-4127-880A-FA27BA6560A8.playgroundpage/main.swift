
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    
    var body: some View {
        NavigationView{
        Text("side")
        Text("panel")
    }
    }
    
}
PlaygroundPage.current.setLiveView(MyView())
    
