
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    
    var body: some View {
        List {
        Label("Lightning", systemImage: "bolt.fill")
        Label("Lightning", systemImage: "bolt.fill")
            .labelStyle(.titleOnly)
            Label("Lightning", systemImage: "bolt.fill")
                .labelStyle(.iconOnly)
        }
    }
    
}
PlaygroundPage.current.setLiveView(MyView())
