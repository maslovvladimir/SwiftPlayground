
import SwiftUI
import PlaygroundSupport

struct MyView: View {
    
    var body: some View {
        List {
            HStack {
                Image(systemName: "trash.circle.fill")
                Text("Take out the trash")
            }
            
            HStack {
                Image(systemName: "person.2.fill")
                Text("Pick up the kids") }
            
            HStack {
                Image(systemName: "car.fill")
                Text("Wash the car")
            }
        }
    }
    
}
let view = MyView()
PlaygroundPage.current.setLiveView(view)
