
import CoreMotion
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

extension Int {
    func format(f: String) -> String {
        return String(format: "%\(f)d", self)
    }
}

extension Double {
    func format(f: String) -> String {
        return String(format: "%\(f)f", self)
    }
    func f3() -> String {
        return String(format: "%.3f", self)
    }
    
    var ff3: String {String(format: "%.3f", self)}
}

let manager = CMMotionManager()
manager.startAccelerometerUpdates()

repeatEvery(0.5) {
    guard let acceleration = manager.accelerometerData?.acceleration else { return }
    let format = ".3"
    let x = acceleration.x.format(f: format)
    let y = acceleration.y.ff3
    let z = acceleration.z.f3()
    print("x = " + x + " y = " + y + " z = " + z ) 
}
