
import CoreMotion
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true
extension Double {
    func format(f: String) -> String {
        return String(format: "%\(f)f", self)
    }
    func f3() -> String {
        return String(format: "%.3f", self)
    }
    var ff3: String {String(format: "%.3f", self)}
}    

let manager = CMMotionManager()
manager.startGyroUpdates()

repeatEvery(0.5) {
    guard let rotation = manager.gyroData?.rotationRate else { return } 
    print("\(rotation.x.ff3)")
}
