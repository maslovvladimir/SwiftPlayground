
import CoreMotion
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let manager = CMMotionManager()
manager.startGyroUpdates()

repeatEvery(0.5) {
    guard let rotation = manager.gyroData?.rotationRate else { return } 
    print("\(rotation.x.round)")
}
