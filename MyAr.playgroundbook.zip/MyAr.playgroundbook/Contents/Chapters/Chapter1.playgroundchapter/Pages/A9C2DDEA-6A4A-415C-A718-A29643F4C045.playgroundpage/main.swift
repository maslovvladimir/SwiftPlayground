/*
 https://www.youtube.com/watch?v=f3xFpRWZEz8
 */

import SwiftUI
import RealityKit
import ARKit
import UIKit
import PlaygroundSupport
//import SharedCode 

struct ContentView: View {
    public var body: some View {
        VStack {
            ARViewContainer()
            //ControlView()
            Text("Hello")
        }
        //.edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable { 
    typealias UIViewType = ARSCNView
    let configuration = ARWorldTrackingConfiguration()
    
    func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) ->   UIViewType {
        //let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        let seneView = UIViewType()
        seneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints,  ARSCNDebugOptions.showWorldOrigin
        ]
        seneView.session.run(configuration)
        //addCube(arView: arView)
        //testFunc() 
        var node = SCNNode()
        node.geometry = SCNBox(width:  0.1, height: 0.1, length: 0.1, chamferRadius: 0)
        node.geometry?.firstMaterial?.diffuse.contents = UIColor.blue
        node.position = SCNVector3(0, 0 , -0.2)
        node.orientation = SCNVector4(0, 1, 0, 3.14/4)
        seneView.scene.rootNode.addChildNode(node)
        return seneView
    } 
    func updateUIView(_ uiView: ARSCNView, context: UIViewRepresentableContext<ARViewContainer>) {}
    
}

 
 
PlaygroundPage.current.setLiveView(ContentView())

/*
 https://www.youtube.com/watch?v=R1XHWyprFVk
 */

import SwiftUI
import RealityKit
import PlaygroundSupport
//import SharedCode 

struct ContentView: View {
    public var body: some View {
        VStack {
            ARViewContainer()
            //ControlView()
            Text("Hello")
        }
        //.edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable { 
    typealias UIViewType = ARView
    
    func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) ->   ARView {
        let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        
        addCube(arView: arView)
        //testFunc() 
        return arView
    } 
    func updateUIView(_ uiView: ARView, context: UIViewRepresentableContext<ARViewContainer>) {}
    
}

 
 
PlaygroundPage.current.setLiveView(ContentView())


