
import CoreMotion
import Foundation

extension Double {
    func roundTo(places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
}
/// Starts the services that report movement detected by the device's sensors. Use this object to receive four types of motion data: accelerometer data, gyroscope data, magnetometer data, and device-motion data. 
public class MotionSensor {
    
    let motionSensor = CMMotionManager()
    
    public init(updateInterval: TimeInterval = 0.01) {
        self.updateInterval = updateInterval
        start()
    }
    
    /// Start receiving sensor data.
    public func start() {
        if motionSensor.isDeviceMotionAvailable {
            motionSensor.startDeviceMotionUpdates()
        }
        
        if motionSensor.isAccelerometerAvailable {
            motionSensor.startAccelerometerUpdates()
        }
        
        if motionSensor.isMagnetometerAvailable {
            motionSensor.startMagnetometerUpdates()
        }
    }
    
    /// Stop receiving sensor data.
    public func stop() {
        motionSensor.stopDeviceMotionUpdates()
        
        if motionSensor.isAccelerometerAvailable {
            motionSensor.stopAccelerometerUpdates()
        }
        
        motionSensor.stopMagnetometerUpdates()
    }
    
    /// Receive sensor data at a specified update interval.
    public var updateInterval: TimeInterval {
        get {
            return motionSensor.deviceMotionUpdateInterval
        }
        set {
            motionSensor.deviceMotionUpdateInterval = newValue
            motionSensor.accelerometerUpdateInterval = newValue
            motionSensor.magnetometerUpdateInterval = newValue
        }
    }
    
    /// The latest sample of device-motion data.
    public var deviceMotion: CMDeviceMotion?  {
        return motionSensor.deviceMotion
    }
    
    /// Sets the function that’s called when a device motion update occurs. This is the event handler for a device motion event.
    public func setOnUpdateHandler(_ handler: @escaping () -> Void) {
        motionSensor.startDeviceMotionUpdates(to: OperationQueue.current!, withHandler: { deviceMotion, error in
            handler()
        })
    }
    
    /// The latest sample of attitude data.
    public var attitude: Attitude {
        guard let motion = motionSensor.deviceMotion?.attitude else { return Attitude(roll: 0, pitch: 0, yaw: 0) }
        return Attitude(currentAttitude: motion)
    }
    
    /// The latest sample of acceleration data.
    public var acceleration: Acceleration {
        guard let motion = motionSensor.accelerometerData?.acceleration else { return Acceleration(currentAcceleration: CMAcceleration(x: 0, y: 0, z: 0)) }
        return Acceleration(currentAcceleration: motion)
    }
    
    /// The latest sample of magnetic field data.
    public var magneticField: MagneticField {
        guard let magneticField = motionSensor.magnetometerData?.magneticField else { return MagneticField(currentMagneticField: CMMagneticField(x: 0, y: 0, z: 0)) }
        return MagneticField(currentMagneticField: magneticField)
    }
}

/// The acceleration measured by the accelerometer, containing three-axis acceleration values: x, y, and z.
public class Acceleration {
    
    /// The acceleration measured by the accelerometer.
    public var acceleration = CMAcceleration()
    
    /// Creates an instance of the Acceleration class.
    public init() {
        
    }
    
    /// A convenience initializer for Acceleration of the latest sample of acceleration data.
    public init(currentAcceleration: CMAcceleration) {
        acceleration = currentAcceleration
    }
    
    /// Y-axis acceleration in gravitational force (G). A “G” is a unit of gravitation force equal to that exerted by Earth’s gravitational field (9.81 m s−2).
    public var y: Double {
        return Double(acceleration.y).roundTo(places: 2)
    }
    
    /// X-axis acceleration in gravitational force (G). A “G” is a unit of gravitation force equal to that exerted by Earth’s gravitational field (9.81 m s−2).
    public var x: Double {
        return Double(acceleration.x).roundTo(places: 2)
    }
    
    /// Z-axis acceleration in gravitational force (G). A “G” is a unit of gravitation force equal to that exerted by Earth’s gravitational field (9.81 m s−2).
    public var z: Double {
        return Double(acceleration.z).roundTo(places: 2)
    }
}

/// Measurements of Earth's magnetic field relative to the device.
public class MagneticField {
    
    /// Measurements of Earth's magnetic field relative to the device.
    public var magneticField = CMMagneticField()
    
    /// Creates an instance of the MagneticField class.
    public init() {
        
    }
    
    /// A convenience initializer for the current magneticField data.
    public init(currentMagneticField: CMMagneticField) {
        magneticField = currentMagneticField
    }
    
    /// Return the magnetic field’s y value.
    public var y: Double {
        return Double(magneticField.y).roundTo(places: 2)
    }
    
    /// Return the magnetic field’s x value.
    public var x: Double {
        return Double(magneticField.x).roundTo(places: 2)
    }
    
    /// Return the magnetic field’s z value.
    public var z: Double {
        return Double(magneticField.z).roundTo(places: 2)
    }
}


/// An object that reports movement detected by the device’s motion sensors.
public class Attitude {
    
    /// Stores the raw Core Motion attitude.
    public var cmAttitude = CMAttitude()
    
    /// Creates an instance of the Attitude class with roll, pitch, and yaw.
    public init(roll: Double, pitch: Double, yaw: Double) {
        self.roll = roll
        self.pitch = pitch
        self.yaw = yaw
    }
    
    /// Creates an instance of the Attitude class to access the latest attitude data.
    public init(currentAttitude: CMAttitude) {
        cmAttitude = currentAttitude
        self.roll = cmAttitude.roll
        self.pitch = cmAttitude.pitch
        self.yaw = cmAttitude.yaw
    }
    
    /// A roll is a rotation around a longitudinal axis that passes through the device from its top to bottom.
    public var roll: Double
    
    /// A pitch is a rotation around a lateral axis that passes through the device from side to side.
    public var pitch: Double
    
    /// A yaw is a rotation around an axis that runs vertically through the device. It is perpendicular to the body of the device, with its origin at the center of gravity and directed toward the bottom of the device.
    public var yaw: Double
    
    /// Return the change in Attitude from a passed in attitude.
    ///
    /// - Parameter attitude: A starting attitude that you specify.
    public func changeInAttitude(from attitude: Attitude) -> Attitude {
        cmAttitude.multiply(byInverseOf: attitude.cmAttitude)
        return Attitude(currentAttitude: cmAttitude)
    }
}
