// Code inside modules can be shared between pages and other source files.
import RealityKit

public func testFunc( )
{
    print("testFunc()")
}

public func addCube(arView: ARView) {
    let mesh = MeshResource.generateBox(size: 0.2)
    let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
    let modelEntity = ModelEntity(mesh:mesh, materials: [material]) 
    //let modelEntity = try ModelEntity.load(named: "toy_biplane.usdz")
    //let modelEntity = try ModelEntity.load(named: "toy_robot_vintage.usdz")  
    let anchorEntity = AnchorEntity(plane: .horizontal)
    anchorEntity.name = "CubeAnchor"
    arView.installGestures( [.translation, .rotation, .scale], for: modelEntity)
    
    anchorEntity.addChild(modelEntity)
    arView.scene.addAnchor(anchorEntity) 
}
